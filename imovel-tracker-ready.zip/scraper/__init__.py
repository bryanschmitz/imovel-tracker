# __init__.py - parte do sistema de monitoramento de imóveis
