# dtx.py - parte do sistema de monitoramento de imóveis
