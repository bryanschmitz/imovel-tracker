# utilidades comuns
