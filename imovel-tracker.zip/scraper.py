# script principal
